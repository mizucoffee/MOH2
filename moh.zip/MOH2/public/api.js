axios.defaults.baseURL = "https://keshipin.mizucoffee.net";
let ws = new WebSocket("ws://keshipin.mizucoffee.net/connect");
var myEraserId = -1;

function getParams(json) {
  const params = new URLSearchParams();
  for (const property in json) {
    params.append(property, json[property]);
  }
  return params;
}

async function start(x, y) {
  const result = await axios.post("/start", getParams({ x, y }));
  myEraserId = result.data.id;
  console.log(result.data);
  return result.data.erasers;
}

async function eraserSnap(angle, power) {
  const result = await axios.post(
    "/eraser/snap",
    getParams({ id: myEraserId, angle, power })
  );
  return result.data;
}

async function snapReserve() {
  const result = await axios.post(
    "/snap/reserve",
    getParams({ id: myEraserId })
  );
  return result.data;
}

async function eraserPosition(x, y) {
  const result = await axios.post(
    "/eraser/position",
    getParams({ id: myEraserId, x, y })
  );
  return result.data;
}

ws.onopen = () => console.log("connection opened");
ws.onclose = () => console.log("connection closed");
ws.onmessage = (m) => {
  switch (m.data.event) {
    case "snap":
      // 他プレイヤーが弾いた
      console.log(m.data)
      break;
    case "turn":
      // 自ターンが来た
      break;
  }
};
